% Create a Simulink model
mdl = 'BodyModelVibrationExample';
open_system(new_system(mdl));

% Load a 3-D gear model
load('gear.mat');

% Add a File Solid block to import the gear model as a body element
add_block('sm_lib/Body Elements/File Solid',[mdl '/Gear']);
set_param([mdl '/Gear'],'Position',[200 100 250 150]);
set_param([mdl '/Gear'],'Geometry',gear);

% Add a Rigid Transform block to set the position and orientation of the gear
add_block('sm_lib/Body Elements/Rigid Transform',[mdl '/Rigid Transform']);
set_param([mdl '/Rigid Transform'],'Position',[150 100 200 150]);
set_param([mdl '/Rigid Transform'],'Translation','[0.1;0;0]');
set_param([mdl '/Rigid Transform'],'Rotation','[0;0;90]');

% Add a Revolute Joint block to connect the gear to the world frame and set the rotation speed
add_block('sm_lib/Joints/Revolute Joint',[mdl '/Revolute Joint']);
set_param([mdl '/Revolute Joint'],'Position',[100 100 150 150]);
set_param([mdl '/Revolute Joint'],'Primitive','Z');
set_param([mdl '/Revolute Joint'],'q_InitialCondition','0');
set_param([mdl '/Revolute Joint'],'w_InitialCondition','22.5');

% Add a Joint Sensor block to measure the angular velocity and acceleration of the gear
add_block('sm_lib/Sensors & Actuators/Joint Sensor',[mdl '/Joint Sensor']);
set_param([mdl '/Joint Sensor'],'Position',[250 100 300 150]);
set_param([mdl '/Joint Sensor'],'Measurements','w,qdd');

% Add a PS-Simulink Converter block to convert physical signals to Simulink signals
add_block('simscape/PS-Simulink Converter',[mdl '/PS-Simulink Converter']);
set_param([mdl '/PS-Simulink Converter'],'Position',[300 125 330 175]);

% Add a Scope block to display Simulink signals
add_block('simulink/Sinks/Scope',[mdl '/Scope']);
set_param([mdl '/Scope'],'Position',[350 125 380 175]);

% Connect blocks with lines
add_line(mdl,'Rigid Transform/RConn1','Gear/LConn1');
add_line(mdl,'Revolute Joint/RConn1','Rigid Transform/LConn1');